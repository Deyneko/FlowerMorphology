#define _FUNC__
#include "flower1.h"
using namespace cv; 
using namespace std;


// function calculates Euclidian distance between two points
double dist(Point p1, Point p2)
{
return sqrt(pow((double)(p1.x-p2.x),2)+pow((double)(p1.y-p2.y),2));
}


// function finds indexes of pset points in contour array
vector <int> curvePoints2Indices(vector <Point> contour, vector <Point> pset)
{
	vector <int> idx (pset.size() + 1);
	int i = 0;
	for(i = 0; i < pset.size(); i++)
		for(int j = 0; j < contour.size(); j++)
			if (pset[i].x == contour[j].x && pset[i].y == contour[j].y){
				idx[i] = j;
				break;
			}
	idx[i] = idx[0];
	return idx;
}

int approxRange(vector<Point> contour, int apex_no)
{
int i = 0, j = 0, k = 0;
int begin = 10;
int end = 350;
int start = 25, stop = 30;
int real_ap_no = 0;
double s=0, ss=0, min = 650000;
double div = 0.35;//0.35; //acceptabe differences in distances between points
bool flag = true;
vector <Point>  apprx ( contour.size() );

	s = contourArea(contour, true);
	for(i = begin; i <= end; i++) {
		approxPolyDP(contour, apprx, (double)i, true);
		ss = contourArea(apprx, true);
		for(j = 1, flag = true; j < apprx.size()-1; j++) {
			if(fabs(dist(apprx[j+1], apprx[j]) - dist(apprx[j], apprx[j-1])) > dist(apprx[j], apprx[j+1]) * div)
				flag = false; 
			}
		if(flag == true && apprx.size() == apex_no && abs(ss-s) < min && isContourConvex(apprx)) 
		{ min = abs(ss-s); k = i; real_ap_no = apprx.size(); }
	}

return k ? k : ((start + stop)/2);
}




// function separates slices of the contour (semipetals parts)
vector <vector <Point>> contourSliceNew(vector <vector<Point>> cnt, int cnt_no, int p1, int p2, Point cent)
{
	vector <vector <Point>> v(cnt.size());
	vector <Point> vv(cnt[cnt_no].size() + 3);
	vv.assign(vv.size(), Point(0, 0));
	Point2i c = Point2i(0, 0);
	int i = 0, j = 0;
	c.x = p1; c.y = p2;
	// �.� and c.y - indexes of the beginning and the end of the separated part of contour

	if (c.x - c.y > 0) {
		for (i = c.x, j = 0; i < cnt[cnt_no].size(); i++, j++)
			vv.at(j) = cnt[cnt_no].at(i);
		for (i = 0; i <= c.y; i++, j++)
			vv.at(j) = cnt[cnt_no].at(i);
		if (cent != Point(0, 0))
			vv.at(j++) = cent;
		vv.at(j++) = vv.at(0);
		vv.resize(j);
	}
	else {
		for (i = c.x, j = 0; i <= c.y; i++, j++)
			vv.at(j) = cnt[cnt_no].at(i);
		if (cent != Point(0, 0))
			vv.at(j++) = cent;
		vv.at(j++) = vv.at(0);
		vv.resize(j);
	}
	v[cnt_no] = vv;
	//printf("\nPoint1 = %d %d Point2 = %d %d",p1.x, p1.y, p2.x, p2.y);
	return v;
}


// fuction finds mean color of corolla
vector <float> findColors(Mat img, vector <Point> c1, vector <Point> c2)
{

float p1=0, p2=0;
int k  = 0;
int R = 0, G = 0, B = 0;
Vec3f sum = Vec3f(0,0,0), sumsq = Vec3f(0,0,0);
vector <float> res (6);
/*
[0] - mean Blue
[1] - mean Green
[2] - mean Red
[3] - sigma for Blue
[4] - sigma for Green
[5] - sigma for Red
*/
for( int j = 0; j < img.rows; j++ ) {
	for( int i = 0; i < img.cols; i++ ) {
		p1 = pointPolygonTest( c1, Point2f(i,j), false ); 
		p2 = pointPolygonTest( c2, Point2f(i,j), false ); 
		if(p1 > 0 && p2 < 0) {
			B = img.at<Vec3b>(j,i)[0];
			G = img.at<Vec3b>(j,i)[1];
			R = img.at<Vec3b>(j,i)[2];
			sum += Vec3f (B,G,R);
			sumsq += Vec3f (B*B, G*G, R*R);
			k++;
			}
		}
	}
res.at(0) = sum[0] / k;
res.at(1) = sum[1] / k;
res.at(2) = sum[2] / k;
res.at(3) = sqrt(sumsq[0] / k - pow(sum[0] / k, 2));
res.at(4) = sqrt(sumsq[1] / k - pow(sum[1] / k, 2));
res.at(5) = sqrt(sumsq[2] / k - pow(sum[2] / k, 2));
//	printf("\nk = %d %lf  %lf  %lf\n",k,res.at(0),res.at(1),res.at(2));
return res;
}

 // function realized the "Walking" method of finding external and internal vertices of corolla
vector <vector <Point>> getCriticalPoints(vector <vector <Point>> con, int con_no)

{
	Point2f cenn(0.0, 0.0), c(0.0, 0.0), cc(0.0, 0.0), tmp(0.0, 0.0);
int tmpidx = 0;
float radn=0.0, r=0.0, rr=0.0;
int i = 0, j = 0, k = 0, m = 0, n = 0, p = 0, u = 0, w = 0, a = 0, b = 0, d = 0;
int no = 0;
bool flag = true, pflag = true;
//////////////////////////////////////// variable parameters
double lim = 0.001; //1.0
double maxlim = 1.3;
double alim = 0.01; 
int thresh = 12; //15
int maxthresh = 18;
int offset = 30;
////////////////////////////////////////
double max_dist = 0.0, min_dist = 10000.0;
vector <Point> ex(con[con_no].size() + 1), in(con[con_no].size() + 1), sum(con[con_no].size() + 1);
vector <vector <Point>> m_ex(200), m_in(200), m_sum(200);
vector <vector <int>> m_sumIdx(200);
vector <int> m_thresh(200);
vector <float> wlim(200);
vector <vector <Point>> dsum (4);
vector <Point> ds(2);
vector <double> dst(con[con_no].size());
vector <double> l0, l1;


sumIdx.resize(con[con_no].size()+1);
minEnclosingCircle(con[con_no], cenn, radn); //Determination of corolla geometric center and radius

for (i = 0; i < con[con_no].size(); i++) // Calculation distances between all contour points and its center
	dst[i] = dist(con[con_no][i], cenn);

// unfolding corolla
/*Mat unfold = image.clone();
unfold = bb_color;

for (i = 0; i < con[con_no].size(); i+=2)
	line(unfold, Point(i/2 + 31, unfold.rows-100), Point(i/2 + 31, unfold.rows-dst[i]-100), p_color, 1, 8, 0);
imshow("Unfolded corolla", unfold);
*/



//finding external and internal vertices 
//FILE *ff = fopen("debug.txt", "w");

for (u = 0; thresh <= maxthresh; thresh++){
	for (p = 0 /*, u = 0*/; lim < maxlim; p++, lim += alim){
		for (i = 1, j = 0, k = 0, m = 0, n = 0, no = 0; i < dst.size(); i++) {

			if ((dst[i] - dst[i - 1]) >= lim && !flag) {
				flag = true;
				pflag = true;
				j = 0;
				//	for (u = i, w = 0; u < i + 10 && u < dst.size(); u++)
				//	if (dst.at(u) - dst.at(u - 1) < lim ) w = u;
				tmp = con[con_no].at(i - 1);//possible internal vertex 
				tmpidx = i - 1;
				//max_dist = dist(con[con_no].at(i), cen); 
			}
			
		//	if (u==10) printf(" i=%d mark %d ", i, 1);

			if ((dst[i] - dst[i - 1]) >= lim && flag)
				j++;
			
			//if (u == 10) printf(" i=%d mark %d ", i, 2);

			//if(j < thresh && dist(con[con_no].at(i), cen ) > max_dist)
			//{ j = 0; tmp = con[con_no].at(i); max_dist = dist(con[con_no].at(i), cen); } 

			if ((dst[i] - dst[i - 1]) <= -lim && flag) {
				flag = false;
				pflag = true;
				j = 0;

				//for (u = 0, w = 0; u <  10 && u+i < dst.size(); u++)
				//if (abs(dst.at(u+i) - dst.at(u+i - 1)) < lim / 2 && i - u / 2 > 0 /*con[con_no].size()+1*/)
				//w = u/2;
				tmp = con[con_no].at(i - 1);// possible external vertex
				tmpidx = i - 1;

				//min_dist = dist(con[con_no].at(i), cen);
			}

			//if (u == 10) printf(" i=%d mark %d ", i, 3);

			if ((dst[i] - dst[i - 1]) <= -lim && !flag)
				j++;

			//if (u == 10) printf(" p= %d i=%d mark %d ", p, i, 4);

			//if(j < thresh && dist(con[con_no].at(i), cen ) < min_dist)
			//{ j = 0; tmp = con[con_no].at(i); max_dist = dist(con[con_no].at(i), cen); } 

			if (j == thresh && pflag) {

				//if (u == 10) printf(" i=%d mark %d ", i, 5);

		/*		if (tmpidx != 0 && tmpidx != dst.size() - 1){
					if ((flag == true && dst[((tmpidx - offset) >= 0) ? (tmpidx - offset) : 0] > dst[tmpidx]
					&& dst[((dst.size() - 1 - tmpidx - offset) >= 0) ? (tmpidx + offset) : (dst.size() - 1)] > dst[tmpidx])
					|| (flag == false && dst[((tmpidx - offset) >= 0) ? (tmpidx - offset) : 0] < dst[tmpidx]
					&& dst[((dst.size() - 1 - tmpidx - offset) >= 0) ? (tmpidx + offset) : (dst.size() - 1)] < dst[tmpidx])){
					sumIdx[k] = tmpidx;
					sum[k++] = tmp;
					j = 0;
					pflag = false;
					if (flag) in[m++] = tmp;
					else ex[n++] = tmp;
					}
					}
					else */

								
				if (tmpidx > offset && (dst.size() > (tmpidx + offset + 1))){
					if (flag == true && (dst[tmpidx - offset] - dst[tmpidx] <= 0 || dst[tmpidx + offset] - dst[tmpidx] <= 0)){
						no++;
						continue;
					}
					//printf(" p = %d i=%d mark %d tmpidx = %d dst.size = %d if = %d", p, i, 6, tmpidx, dst.size(), dst.size() - tmpidx - offset - 1);
					if (flag == false && (dst[tmpidx - offset] - dst[tmpidx] > 0 || dst[tmpidx + offset] - dst[tmpidx] > 0)){
						no++;
						continue;
					}
				}

			//	if(u==10) printf(" \np = %d i=%d mark %d ", p, i, 7);

			        //finding minimum or maximum radial in the vicinity of probable vertex
				d = 0;
				min_dist = 64000.0;
				max_dist = 0.0;
				if (tmpidx - offset < 0) {
					for (a = dst.size() - 1 - offset + tmpidx; a < dst.size(); a++) {
						if (!flag && max_dist < dst[a]) { max_dist = dst[a]; b = a; }
						if (flag && min_dist > dst[a]) { min_dist = dst[a]; b = a;  }
					}
			/*###*/		for (a = 0; a < tmpidx + offset; a++) {
						if (!flag && max_dist < dst[a]) { max_dist = dst[a]; b = a;  }
						if (flag && min_dist > dst[a]) { min_dist = dst[a]; b = a; }
					}
				}
				min_dist = 64000.0;
				max_dist = 0.0;
				if (tmpidx + offset >= dst.size()) {
					for (a = tmpidx - offset; a < dst.size(); a++) {
						if (!flag && max_dist < dst[a]) { max_dist = dst[a]; b = a; }
						if (flag && min_dist > dst[a]) { min_dist = dst[a]; b = a; }
					}
			/*###*/		for (a = 0; a < tmpidx + offset - dst.size(); a++) {
						if (!flag && max_dist < dst[a]) { max_dist = dst[a]; b = a; }
						if (flag && min_dist > dst[a]) { min_dist = dst[a]; b = a; }
					}
				} 
				min_dist = 64000.0;
				max_dist = 0.0;
				if (tmpidx + offset < dst.size() && tmpidx - offset >= 0) {
					for (a = tmpidx - offset; a <= tmpidx + offset; a++) {
						if (!flag && max_dist < dst[a]) { max_dist = dst[a]; b = a; }
						if (flag && min_dist > dst[a]) { min_dist = dst[a]; b = a; }
				}
			}
			tmpidx = b;
			tmp = con[con_no].at(tmpidx);
			
				sumIdx[k] = tmpidx;
				sum[k++] = tmp;
				j = 0;
				pflag = false;
				if (flag) in[m++] = tmp;
				else ex[n++] = tmp;

				
			}

			//if (u == 10) printf(" i=%d mark %d lim = %f", i, 8, lim);
		} // end of i cycle  
		
		//printf("\nu=%d lim = %f ", u, lim);

		max_dist = 0.0;
		min_dist = 10000.0;
		for (int ii = 0; ii < k - 1; ii++)
			if (min_dist > dist(sum[ii], sum[ii + 1]))
				min_dist = dist(sum[ii], sum[ii + 1]);

		//if(u==10) printf(" i=%d mark %d ", i, 9);

		//printf("\np=%d Lim = %f k = %d m = %d n = %d min_dist = %f no = %d thresh = %d", p, lim, k, m, n, min_dist, no, thresh);
		//fprintf(ff,"\np=%d Lim = %f k = %d m = %d n = %d min_dist = %f no = %d", p, lim, k, m, n, min_dist, no);
		
		if (k == 10 && m == 5 && n == 5 && min_dist > 50) {
			m_sum[u] = sum; m_in[u] = in; m_ex[u] = ex; m_sumIdx[u] = sumIdx; m_thresh[u] = thresh; wlim[u] = lim;
			m_sum[u].resize(k); m_in[u].resize(m); m_ex[u].resize(n); m_sumIdx[u].resize(k);
			u++;
			//printf("\np = %d u = %d   con[con_no].size = %d thresh = %d lim=%f maxlim=%f", p, u, con[con_no].size(), thresh, lim, maxlim);
		}
		

	} //end of p cycle  
	//printf("\nEnd of p cycle lim = %f thresh = %d", lim, thresh);
} //end of q cycle (thresh) 


/*///////////////////////////////////
for (a = 0; a < 10; a++)
	printf("  sum[%d].x = %d  ", a, sum[a].x);
////////////////////////////////////*/

//printf("\nResult p=%d Lim = %f k = %d m = %d n = %d min_dist = %f no = %d", p, lim,k,m,n,min_dist, no);
//fprintf(ff, "\nResult p=%d Lim = %f k = %d m = %d n = %d min_dist = %f no = %d", p, lim, k, m, n, min_dist, no);
//fclose(ff);
//if (k != 10 || m != 5 || n != 5 || min_dist <= 100) return dsum;
//sum.resize(k);
//in.resize(m);
//ex.resize(n);
//printf("\nu = %d lim = %f thresh = %d", u, lim, thresh - 1);
//////////////////////////////////////////////////////
if (u == 0) { ds[0] = Point(0, 0);  dsum[0] = ds; return dsum; }
//////////////////////////////////////////////////////
m_sum.resize(u?u:1);
m_sumIdx.resize(u?u:1);
wlim.resize(u?u:1);

//finding the best vertices set using angles between radials
//minimum meansquare deviation from 36 degrees
int min = 65000;
int min_u = 0, min_w = 0;
int cur = 0;
for (i = 0, cur = 0; i < m_sum.size(); i++) {
	l0 = getAngles(m_sum[i], cenn);
	//printf("\nl0.size = %d", l0.size());
	for (j = 0, cur = 0; j < l0.size(); j++)
			cur += pow(l0.at(j) - 36.0 , 2);
	if (min > cur) { min = cur; min_w = min_u;  min_u = i; }
	//printf("\ni = %d min = %d cur = %d",i,min,cur);
	}
sum = m_sum[min_u];
ex = m_ex[min_u];
in = m_in[min_u];
sIdx.resize(m_sumIdx.size());
sIdx = m_sumIdx[min_u];
sumIdx = m_sumIdx[min_u];
sumIdx.resize(m_sumIdx.size());
thresh = m_thresh[min_u];
st_lim = wlim[min_u];
//printf("\nmin_u = %d u = %d", min_u, u);


/*//////////////////
dsum[0] = sum;
drawContours(test, dsum, 0, y_color, 2);
imshow("Test", test);
waitKey(0);
///////////////////////////////*/

// combining Convex-Hull and Walking data

for (i = 0, j = 0; i < ex.size(); i++, j += 2){
	vicon[i] = in[i];
	/*if (abs(ex[i].x - oldcon[con_no][i].x) < 30 && abs(ex[i].y - oldcon[con_no][i].y) < 30 
		&& oldcon[con_no].size() == 5){
		vecon[i] = (ex[i] + oldcon[con_no][i]) / 2;
		vcon[j] = (ex[i] + oldcon[con_no][i]) / 2;
	} else {*/
		vecon[i] = ex[i];
		vcon[j] = ex[i];
	//}
	vcon[j + 1] = in[i];
}
//printf("\nMark 1");
vcon.resize(j);
vicon.resize(i);
vecon.resize(i);

dsum[0] = vcon;
dsum[1] = vicon;
dsum[2] = vecon;
ds[0] = Point(thresh, 0);
dsum[3] = ds; 
st_thr = thresh;
ThFlag = true;

//printf("\nMark 2");
/*&&&&&&&
drawContours(test, con, con_no, bk_color, 2);
drawContours(test, dsum, 0, y_color, 2);
drawContours(test, dsum, 1, g_color, 2);
drawContours(test, dsum, 2, r_color, 2);
drawContours(test, c_contours, c_contour_no, y_color, 2);
//printf("\n1");
minEnclosingCircle(c_contours[c_contour_no], cc, rr );
circle(test, cc, rr, b_color, 2, 8);



for(i = 0; i < vicon.size(); i++)
	circle(test, vicon[i] ,5, g_color, 5, 8);
for(i = 0; i < vecon.size(); i++)
	circle(test, vecon[i], 5, r_color, 5, 8);
	
//for (i = 0; i < ex.size(); i++)
	//circle(test, ex[i], 5, m_color, 5, 8);

drawContours(test, dsum, 0, y_color, 2);
//drawContours(test, con, con_no, bk_color, 2);

//printf("\n2");
circle(test, cenn, 3, bk_color, 5, 8);
circle(test, cenn, radn, p_color, 2, 8);

minEnclosingCircle(vicon, c, r);
circle(test, c, r, bb_color, 2, 8);
&&&&&&&*/
/*
for (i = 0; i < sum.size(); i++){
	if (sumIdx[i] + offset < con[con_no].size())
		circle(test, con[con_no][sumIdx[i] + offset], 3, w_color, 2, 8);
	else
		circle(test, con[con_no][offset], 3, w_color, 2, 8);
	if (sumIdx[i] - offset >= 0)
		circle(test, con[con_no][sumIdx[i] - offset], 3, bk_color, 2, 8);
	else
		circle(test, con[con_no][con[con_no].size() - offset], 3, bk_color, 2, 8);
	} */
//printf("\n3");
//&&&&& for (i = 0; i < vcon.size(); i++)
	//&&&&&line(test, vcon[i], cenn, bk_color, 2, 8, 0); 
/*
l0 = getAngles(vcon, cenn);
for (i = 0; i < sum.size();i++)
	printf("\n Angle [%d] = %f ", i, l0[i]);

l1 = getAngles(tcc, center);
//for (i = 0; i < tcc.size(); i++)
	//printf("\n Angle [%d] = %f ", i, l1[i]);
*/

/*
double sum0 = 0, sum1 = 0;
const double s = 36.0, d = 5.0;
vector <Point> vcon = tcc; 
for (i = 0; i < l0.size() - 1; i += 2){
	if (i == 0){
		if (l1.front()-s > d && l1.back()-s < -d)
		sum0 = pow(l0[0]-s,2)  l0[l0.size() - 1] - s);
		sum1 = abs(l1[0] + l1[l1.size() - 1] - s);
	} else {
		sum0 = abs(l0[i-1] + l0[i] - s);
		sum1 = abs(l1[i-1] + l1[i] - s);
	}
	if (sum0 - sum1 > delta)


}
*/


/*
vector <vector <Point>> tcc_(2);
tcc_[0] = tcc;
drawContours(test, tcc_, 0, b_color, 2);
*/
//printf("\n4");
/* &&&&&
imshow("Test", test);
waitKey(0);
destroyWindow("Test");
//destroyWindow("Unfolded corolla");
&&&&& */
return dsum;
}




// function calculate angles between radials
vector <double> getAngles(vector <Point> v, Point c){

#define RG 180.0/3.14159265
	int i = 0;
	vector <double> l0(v.size()), l1(v.size()), l2(v.size()), l3(v.size());

	for (i = 0; i < v.size(); i++){
		if (i != v.size() - 1){
			l0[i] = dist(v[i], c); 	l1[i] = dist(v[i + 1], c); 	l2[i] = dist(v[i], v[i + 1]);
		}
		else {
			l0[i] = dist(v[i], c); 	l1[i] = dist(v[0], c); 	l2[i] = dist(v[i], v[0]);
		}
	}
	for (i = 0; i < v.size(); i++){
		l3[i] = acos((l0[i] * l0[i] + l1[i] * l1[i] - l2[i] * l2[i]) / (2 * l0[i] * l1[i])) * RG;
		}
return l3;
}

int cycVec(int pos, int size)
{
	int p = 0;
	if (pos >= size)
		p = pos - size - 1;
	if (pos < 0)
		p = size - 1 - pos;
	return p;
}