#define _FILE__
#include "flower1.h"
#include <math.h>

//fuction reads file with results 
int ReadResFile(char *name)
{
	char fname[512];
	char str[2048];
	int i=0, j = 0, field_no = 0;
	FILE *fh;
	DWORD FA = GetFileAttributes("Data");
	if (FA == 0xFFFFFFFF)
		mkdir("Data");
	//if(name == "") name = "Noname";
	sprintf(fname, "Data\\%s.dat", name);
	no_asymmetry_data = 0;
	no_PA = 0;
	if((fh = fopen(fname, "r")) && (_filelength(fileno(fh))!=0))
		{
		for(i=0, j = 0; fgets(str, 10240, fh); i++) {
			field_no = sscanf( str, "%d\t%s\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf", 
				&Dat[i].number, Dat[i].fname, &Dat[i].square, &Dat[i].perimeter, 
				&Dat[i].compactness, &Dat[i].radius, &Dat[i].asymmetry,
				&Dat[i].PA, &Dat[i].PID, &Dat[i].PT, &Dat[i].PC, &Dat[i].ARL, &Dat[i].ARM,
				&Dat[i].PTS, &Dat[i].PTP, &Dat[i].PTCN, &Dat[i].AEI, &Dat[i].APC);
			if(field_no == 6 || Dat[i].asymmetry < 0) { no_asymmetry_data++; Dat[i].asymmetry = -1;}
			if(field_no == 7 || Dat[i].PA < 0) {
				no_PA++;
				Dat[i].PA = -1; // mass petals asymmetry
				Dat[i].PID = -1; // debth of petals incision
				Dat[i].PT = -1; // flower tube radius
				Dat[i].PC = -1; // petals ring width
				Dat[i].ARL = -1; // linear radial asymmery of the flower
				Dat[i].ARM = -1; // mass radial asymmery of the flower
				Dat[i].PTS = -1; // square of the flower tube ochrea
				Dat[i].PTP = -1; // perimetre of the flower tube ochrea
				Dat[i].PTCN = -1; // compactness of the flower tube ochrea
				Dat[i].AEI = -1;  // asymmetry of external and internal corolla vertices 
				Dat[i].APC = -1; // petals ring asymmetry
			}

			}
			
		fclose(fh);
		return (Dat[i-1].number + 1);
		}
	else
		{
		fh=fopen(name, "w");
		fclose(fh);
		return 0;
	}
}

//fuction writes file with results 
int WriteResFile(char *name)
{
	char fname[512];
	char bname[512];
	//char str[2048];
	int i=0;
	FILE *fh;
	DWORD FA = GetFileAttributes("Data");
	if (FA == 0xFFFFFFFF)
		mkdir("Data");
	sprintf(fname, "Data\\%s.dat", name);
	if(fh = fopen(fname, "r")) 
		{
		fclose(fh);
		sprintf(bname, "%s.bak", fname);
		if(fh = fopen(bname, "r")) {
			fclose(fh);
			unlink(bname);
		}
		rename(fname, bname);
		}
	fh = fopen(fname, "w");
	for(i=0; i < counter; i++)
		fprintf(fh, "%d\t%s\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n", 
		i, Dat[i].fname, Dat[i].square, Dat[i].perimeter, Dat[i].compactness, Dat[i].radius, Dat[i].asymmetry,
		Dat[i].PA, Dat[i].PID, Dat[i].PT, Dat[i].PC, Dat[i].ARL, Dat[i].ARM, Dat[i].PTS,
		Dat[i].PTP, Dat[i].PTCN, Dat[i].AEI, Dat[i].APC);
	fclose(fh);
	return i; 
}

// function writes all independently measured in the main cycle data to the file
void Write_cData(void)
{
char ss[10];
FILE *fh = fopen("Data\\current.dat", "w");
	for(int i=0; i < rep; i++) {
		sprintf(cDat[i].fname, "current%s.jpg",_itoa(i,ss,10));
		fprintf(fh, "%d\t%s\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n", i, cDat[i].fname, 
			cDat[i].square, cDat[i].perimeter, cDat[i].compactness,	cDat[i].radius, cDat[i].asymmetry, cDat[i].PA, 
			cDat[i].PID, cDat[i].PT, cDat[i].PC, cDat[i].ARL, cDat[i].ARM, cDat[i].PTS, cDat[i].PTP, cDat[i].PTCN, 
			cDat[i].AEI, cDat[i].APC);
	}
	fclose(fh);
}


//function calculates standart errors of mean values
void StError(void)
{
rData Sum;
	Sum.square = 0;
	Sum.perimeter = 0;
	Sum.compactness = 0;
	Sum.Ncompactness = 0;
	Sum.radius = 0;
	Sum.asymmetry = 0;
	Sum.PA = 0; // mass petals asymmetry
	Sum.PID = 0; // debth of petals incision
	Sum.PT = 0; // flower tube radius
	Sum.PC = 0; // petals ring width
	Sum.ARL = 0; // linear radial asymmery of the flower
	Sum.ARM = 0; // mass radial asymmery of the flower
	Sum.PTS = 0; // square of the flower tube ochrea
	Sum.PTP = 0; // perimetre of the flower tube ochrea
	Sum.PTCN = 0; // compactness of the flower tube ochrea
	Sum.AEI = 0;  // asymmetry of external and internal corolla vertices 
	Sum.APC = 0; // petals ring asymmetry

	// standart errors of the values
	SErr.SEsquare = 0;
	SErr.SEperimeter = 0;
	SErr.SEcompactness = 0;
	SErr.SENcompactness = 0;
	SErr.SEradius = 0;
	SErr.SEasymmetry = 0;
	SErr.SE_PA = 0; 
	SErr.SE_PID = 0; 
	SErr.SE_PT = 0; 
	SErr.SE_PC = 0; 
	SErr.SE_ARL = 0; 
	SErr.SE_ARM = 0; 
	SErr.SE_PTS = 0; 
	SErr.SE_PTP = 0;
	SErr.SE_PTCN = 0;
	SErr.SE_AEI = 0;
	SErr.SE_APC = 0;

for(int i=0;i<counter;i++)
	{
		Sum.square += Dat[i].square;
		Sum.perimeter += Dat[i].perimeter;
		Sum.compactness += Dat[i].compactness;
		Sum.Ncompactness += Dat[i].compactness*pi*4;
		Sum.radius += Dat[i].radius;
		if(Dat[i].asymmetry >= 0)
			Sum.asymmetry += Dat[i].asymmetry;
		if(Dat[i].PA >= 0) {
			Sum.PA += Dat[i].PA; 
			Sum.PID += Dat[i].PID; 
			Sum.PT += Dat[i].PT; 
			Sum.PC += Dat[i].PC; 
			Sum.ARL += Dat[i].ARL; 
			Sum.ARM += Dat[i].ARM; 
			Sum.PTS += Dat[i].PTS; 
			Sum.PTP += Dat[i].PTP;
			Sum.PTCN += Dat[i].PTCN;
			Sum.AEI += Dat[i].AEI;
			Sum.APC += Dat[i].APC;
		}
	}
	// finding the mean values
	SErr.square = Sum.square/counter;
	SErr.perimeter = Sum.perimeter/counter;
	SErr.compactness = Sum.compactness/counter;
	SErr.Ncompactness = Sum.Ncompactness/counter;
	SErr.radius = Sum.radius/counter;
	SErr.asymmetry = Sum.asymmetry/(counter - no_asymmetry_data);
	if(counter - no_PA != 0) {
		SErr.PA = Sum.PA/(counter - no_PA); 
		SErr.PID = Sum.PID/(counter - no_PA); 
		SErr.PT = Sum.PT/(counter - no_PA); 
		SErr.PC = Sum.PC/(counter - no_PA); 
		SErr.ARL = Sum.ARL/(counter - no_PA); 
		SErr.ARM = Sum.ARM/(counter - no_PA); 
		SErr.PTS = Sum.PTS/(counter - no_PA); 
		SErr.PTP = Sum.PTP/(counter - no_PA);
		SErr.PTCN = Sum.PTCN/(counter - no_PA);
		SErr.AEI = Sum.AEI/(counter - no_PA);
		SErr.APC = Sum.APC/(counter - no_PA);
	}
	
	Sum.square = 0;
	Sum.perimeter = 0;
	Sum.compactness = 0;
	Sum.Ncompactness = 0;
	Sum.radius = 0;
	Sum.asymmetry = 0;
	Sum.PA = 0; 
	Sum.PID = 0; 
	Sum.PT = 0; 
	Sum.PC = 0; 
	Sum.ARL = 0; 
	Sum.ARM = 0; 
	Sum.PTS = 0; 
	Sum.PTP = 0;
	Sum.PTCN = 0;
	Sum.AEI = 0;
	Sum.APC = 0;

for(int i=0;i<counter;i++)
	{
		Sum.square += (Dat[i].square - SErr.square) * (Dat[i].square - SErr.square);
		Sum.perimeter += (Dat[i].perimeter - SErr.perimeter) * (Dat[i].perimeter - SErr.perimeter);
		Sum.compactness += (Dat[i].compactness - SErr.compactness) * (Dat[i].compactness - SErr.compactness);
		Sum.Ncompactness += (Dat[i].compactness*pi*4 - SErr.Ncompactness) * (Dat[i].compactness*pi*4 - SErr.Ncompactness);
		Sum.radius += (Dat[i].radius - SErr.radius) * (Dat[i].radius - SErr.radius);
		if(Dat[i].asymmetry != -1)
			Sum.asymmetry += (Dat[i].asymmetry - SErr.asymmetry) * (Dat[i].asymmetry - SErr.asymmetry);
		if(Dat[i].PA != -1) {
			Sum.PA += (Dat[i].PA - SErr.PA) * (Dat[i].PA - SErr.PA);
			Sum.PID += (Dat[i].PID - SErr.PID) * (Dat[i].PID - SErr.PID);
			Sum.PT += (Dat[i].PT - SErr.PT) * (Dat[i].PT - SErr.PT);
			Sum.PC += (Dat[i].PC - SErr.PC) * (Dat[i].PC - SErr.PC);
			Sum.ARL += (Dat[i].ARL - SErr.ARL) * (Dat[i].ARL - SErr.ARL);
			Sum.ARM += (Dat[i].ARM - SErr.ARM) * (Dat[i].ARM - SErr.ARM);
			Sum.PTS += (Dat[i].PTS - SErr.PTS) * (Dat[i].PTS - SErr.PTS);
			Sum.PTP += (Dat[i].PTP - SErr.PTP) * (Dat[i].PTP - SErr.PTP);
			Sum.PTCN += (Dat[i].PTCN - SErr.PTCN) * (Dat[i].PTCN - SErr.PTCN);
			Sum.AEI += (Dat[i].AEI - SErr.AEI) * (Dat[i].AEI - SErr.AEI);
			Sum.APC += (Dat[i].APC - SErr.APC) * (Dat[i].APC - SErr.APC);
		}
	}

// finding standart errors
SErr.SEsquare = sqrt(Sum.square/counter)/sqrt((double)counter);
SErr.SEperimeter = sqrt(Sum.perimeter/counter)/sqrt((double)counter);
SErr.SEcompactness = sqrt(Sum.compactness/counter)/sqrt((double)counter);
SErr.SENcompactness = sqrt(Sum.Ncompactness/counter)/sqrt((double)counter);
SErr.SEradius = sqrt(Sum.radius/counter)/sqrt((double)counter);
SErr.SEasymmetry = sqrt(Sum.asymmetry/(double)(counter - no_asymmetry_data))/sqrt((double)(counter - no_asymmetry_data));
if(counter - no_PA != 0) {
	SErr.SE_PA = sqrt(Sum.PA/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PID = sqrt(Sum.PID/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PT = sqrt(Sum.PT/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PC = sqrt(Sum.PC/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_ARL = sqrt(Sum.ARL/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_ARM = sqrt(Sum.ARM/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PTS = sqrt(Sum.PTS/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PTP = sqrt(Sum.PTP/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_PTCN = sqrt(Sum.PTCN/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_AEI = sqrt(Sum.AEI/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
	SErr.SE_APC = sqrt(Sum.APC/(double)(counter - no_PA))/sqrt((double)(counter - no_PA));
}

return;
}