#define _MAIN__ 1
#include "flower1.h"


int main(int argc, char* argv[])
{
	
	// get any video camera connected        
	capture.open(0);
	//assert( capture );        
	if (!capture.isOpened()) {
		printf("\nYou have no video camera connected");
		exit(-1);
	}
	capture.set(CV_CAP_PROP_FRAME_WIDTH, 1280);
	capture.set(CV_CAP_PROP_FRAME_HEIGHT, 1024);
	
	// get width and height of the frame        
	width = capture.get(CV_CAP_PROP_FRAME_WIDTH);
	height = capture.get(CV_CAP_PROP_FRAME_HEIGHT);
	if (width != 1280 || height != 1024) {
		printf("\nYour video camera cannot work with 1280x1024 resolution");
		exit(-1);
	}
	
	char str[512];
	char* s;
	char sss[512];
	mwidth = width/2;
	mheight = height/2;
	
	s = argc >= 2 ? argv[1] : "Noname";
	sprintf(path, "Data\\%s", s);
	sprintf(str, "Real Time Image \"%s\"  %d x %d", s, mwidth, mheight);
	char flag = true;

	//reading file with previous data
	counter = ReadResFile(s);
	if(counter == -1)	{exit(-1);}
	if(counter > 1)
	{
		//counting previous data and writing previous results to file
		StError();
		sprintf(sss,"%s.res", path);
		FILE *f = fopen(sss, "a");
		char pm[]=" +/- ";
		printf("\nSquare S = %lf %s %lf\nPerimeter P = %lf %s %lf\nCompactness C = %lf %s %lf\nNormalized Compactness CN = %lf %s %lf\nRadius R = %lf %s %lf\nAsymmetry A = %lf %s %lf\nNumber of flowers N = %d\n", 
			SErr.square, pm, SErr.SEsquare, SErr.perimeter, pm, SErr.SEperimeter, SErr.compactness, pm, SErr.SEcompactness, 
			SErr.Ncompactness, pm, SErr.SENcompactness, SErr.radius, pm, SErr.SEradius, SErr.asymmetry, pm, SErr.SEasymmetry, counter);
		if(counter - no_PA != 0)
			printf("\nPA = %lf %s %lf\nPID = %lf %s %lf\nPT = %lf %s %lf\nPC = %lf %s %lf\nARL = %lf %s %lf\nARM = %lf %s %lf\nPTS = %lf %s %lf\nPTP = %lf %s %lf\nPTCN = %lf %s %lf\nAEI = %lf %s %lf\nAPC = %lf %s %lf\n",
			SErr.PA, pm, SErr.SE_PA,SErr.PID, pm, SErr.SE_PID,SErr.PT, pm, SErr.SE_PT,SErr.PC, pm, SErr.SE_PC,
			SErr.ARL, pm, SErr.SE_ARL,SErr.ARM, pm, SErr.SE_ARM,SErr.PTS, pm, SErr.SE_PTS,
			SErr.PTP, pm, SErr.SE_PTP, SErr.PTCN, pm, SErr.SE_PTCN, 
			SErr.AEI, pm, SErr.SE_AEI, SErr.APC, pm, SErr.SE_APC);
		fprintf(f, "\nSquare S = %lf %s %lf\nPerimeter P = %lf %s %lf\nCompactness C = %lf %s %lf\nNormalized Compactness CN = %lf %s %lf\nRadius R = %lf %s %lf\nAsymmetry A = %lf %s %lf\nNumber of flowers N = %d\n", 
			SErr.square, pm, SErr.SEsquare, SErr.perimeter, pm, SErr.SEperimeter, SErr.compactness, pm, SErr.SEcompactness,
			SErr.Ncompactness, pm, SErr.SENcompactness, SErr.radius, pm, SErr.SEradius, SErr.asymmetry, pm, SErr.SEasymmetry, counter);
		if(counter - no_PA != 0)
			fprintf(f, "\nPA = %lf %s %lf\nPID = %lf %s %lf\nPT = %lf %s %lf\nPC = %lf %s %lf\nARL = %lf %s %lf\nARM = %lf %s %lf\nPTS = %lf %s %lf\nPTP = %lf %s %lf\nPTCN = %lf %s %lf\nAEI = %lf %s %lf\nAPC = %lf %s %lf\n",
			SErr.PA, pm, SErr.SE_PA,SErr.PID, pm, SErr.SE_PID,SErr.PT, pm, SErr.SE_PT,SErr.PC, pm, SErr.SE_PC,
			SErr.ARL, pm, SErr.SE_ARL,SErr.ARM, pm, SErr.SE_ARM, SErr.PTS, pm, SErr.SE_PTS, 
			SErr.PTP, pm, SErr.SE_PTP, SErr.PTCN, pm, SErr.SE_PTCN, 
			SErr.AEI, pm, SErr.SE_AEI, SErr.APC, pm, SErr.SE_APC);
		fclose(f);
	}
	
	// preparing array for image rotation to the right in 90 degrees
	Rframe.create(Size(height, width), frame.type());
		map_x.create(Size(height, width), CV_32FC1);
		map_y.create(Size(height, width), CV_32FC1);
		for( int l = 0; l < width; l++ )
		{ 
			for( int m = 0; m < height; m++ )
			{
				 map_x.at<float>(l,m) = l ;
                 map_y.at<float>(l,m) = height - m ;
			}
		}

				// reading contour templates from the files
				
				//first template of the external contour
				FileStorage fs("RContour1.xml", FileStorage::READ);
				int RContours_size = (int) fs["RContoursSize"];
				RTemplateContour_no = (int) fs["RTemplateContour_no"];
				int RTemplate_size = (int) fs["RTemplate_size"];
				vector <vector <Point> > rTemplate(RContours_size, vector <Point> (RTemplate_size));
				FileNode n = fs["RTemplate"];
				FileNodeIterator it = n.begin(), it_end = n.end(); // Go through the node
				for (int i=0; it != it_end; ++it,i++) {
					rTemplate[RTemplateContour_no][i].x = (int ) *(it++);
					rTemplate[RTemplateContour_no][i].y = (int) *it;
				}
				fs.release();
				RTemplate = rTemplate;

				//second template of the external contour
				FileStorage fs1("RContour2.xml", FileStorage::READ);
				int RContours1_size = (int) fs1["RContoursSize"];
				RTemplateContour1_no = (int) fs1["RTemplateContour_no"];
				int RTemplate1_size = (int) fs1["RTemplate_size"];
				vector <vector <Point> > rTemplate1(RContours1_size, vector <Point>(RTemplate1_size));
				FileNode n1 = fs1["RTemplate"];
				FileNodeIterator it1 = n1.begin(), it1_end = n1.end(); // Go through the node
				for (int i=0; it1 != it1_end; ++it1,i++) {
					rTemplate1[RTemplateContour1_no][i].x = (int ) *(it1++);
					rTemplate1[RTemplateContour1_no][i].y = (int) *it1;
				}
				fs1.release();
				RTemplate1 = rTemplate1;

				// template of the flower tube ochrea
				FileStorage fs2("RCContour1.xml", FileStorage::READ);
				int RCContours_size = (int) fs2["RCContoursSize"];
				RCTemplateContour_no = (int) fs2["RCTemplateContour_no"];
				int RCTemplate_size = (int) fs2["RCTemplate_size"];
				vector <vector <Point> > rcTemplate(RCContours_size, vector <Point>(RCTemplate_size));
				FileNode n2 = fs2["RCTemplate"];
				FileNodeIterator it2 = n2.begin(), it2_end = n2.end(); // Go through the node
				for (int i=0; it2 != it2_end; ++it2,i++) {
					rcTemplate[RCTemplateContour_no][i].x = (int ) *(it2++);
					rcTemplate[RCTemplateContour_no][i].y = (int) *it2;
				}
				fs2.release();
				RCTemplate = rcTemplate;


	int w = 0;
	char ww[512];

	while(flag){
		// get frame from camera                
		capture >> frame;
		Mat Tframe = frame.clone();

		// image rotation 90 degrees to the right
		Mat Fframe (frame, Rect(mwidth/2, mheight/2, mwidth, mheight));
		remap( frame, Rframe, map_x, map_y, CV_INTER_LINEAR, BORDER_CONSTANT, Scalar(0,0, 0) );
		Mat Mframe (Rframe, Rect((height-mwidth)/2,(width-mheight)/2,mwidth,mheight));
		frame = Mframe;
	
		//put image to the window                
		imshow(str, frame);
		
		int random_n = rand() % 32767;
		int random_n1 = rand() % 32767;
		char * fpp;

		// Key Switch
		char c = cvWaitKey(33);
		switch (c) {
		case 27:   // Escape - exit
			flag = false;
			break;
		case 13:  // Enter - Go to pleliminary image processing                      
			image = Mframe.clone();
			Rcontours(s);
			counter++;
			break;
		case 'w': // write frame to file 
			char nnn[64];
			srand(time(NULL));
			sprintf(nnn, "frame%05d%05d.jpg", random_n, random_n1);
			printf("\n%s",nnn);
			imwrite(nnn, Tframe);
			break;
		default: break;
			}
		}

	//program exit
	if(WriteFlag)
		WriteResFile(s);
	capture.release();
	destroyWindow(str);

	// calculating and writing results to file
	if(counter > 1)
	{
		StError();
		FILE *ff = fopen(sss, "a");
		char pm[]=" +/- ";

		printf("\nSquare S = %lf %s %lf\nPerimeter P = %lf %s %lf\nCompactness C = %lf %s %lf\nNormalized Compactness CN = %lf %s %lf\nRadius R = %lf %s %lf\nAsymmetry A = %lf %s %lf\nNumber of flowers N = %d\n", 
			SErr.square, pm, SErr.SEsquare, SErr.perimeter, pm, SErr.SEperimeter, SErr.compactness, pm, SErr.SEcompactness, 
			SErr.Ncompactness, pm, SErr.SENcompactness, SErr.radius, pm, SErr.SEradius, SErr.asymmetry, pm, SErr.SEasymmetry, counter);
		if(counter - no_PA != 0)
			printf("\nPA = %lf %s %lf\nPID = %lf %s %lf\nPT = %lf %s %lf\nPC = %lf %s %lf\nARL = %lf %s %lf\nARM = %lf %s %lf\nPTS = %lf %s %lf\nPTP = %lf %s %lf\nPTCN = %lf %s %lf\nAEI = %lf %s %lf\nAPC = %lf %s %lf\n",
			SErr.PA, pm, SErr.SE_PA,SErr.PID, pm, SErr.SE_PID,SErr.PT, pm, SErr.SE_PT,SErr.PC, pm, SErr.SE_PC,
			SErr.ARL, pm, SErr.SE_ARL,SErr.ARM, pm, SErr.SE_ARM,SErr.PTS, pm, SErr.SE_PTS,
			SErr.PTP, pm, SErr.SE_PTP, SErr.PTCN, pm, SErr.SE_PTCN, 
			SErr.AEI, pm, SErr.SE_AEI, SErr.APC, pm, SErr.SE_APC);
		fprintf(ff, "\nSquare S = %lf %s %lf\nPerimeter P = %lf %s %lf\nCompactness C = %lf %s %lf\nNormalized Compactness CN = %lf %s %lf\nRadius R = %lf %s %lf\nAsymmetry A = %lf %s %lf\nNumber of flowers N = %d\n", 
			SErr.square, pm, SErr.SEsquare, SErr.perimeter, pm, SErr.SEperimeter, SErr.compactness, pm, SErr.SEcompactness,
			SErr.Ncompactness, pm, SErr.SENcompactness, SErr.radius, pm, SErr.SEradius, SErr.asymmetry, pm, SErr.SEasymmetry, counter);
		if(counter - no_PA != 0)
			fprintf(ff, "\nPA = %lf %s %lf\nPID = %lf %s %lf\nPT = %lf %s %lf\nPC = %lf %s %lf\nARL = %lf %s %lf\nARM = %lf %s %lf\nPTS = %lf %s %lf\nPTP = %lf %s %lf\nPTCN = %lf %s %lf\nAEI = %lf %s %lf\nAPC = %lf %s %lf\n",
			SErr.PA, pm, SErr.SE_PA,SErr.PID, pm, SErr.SE_PID,SErr.PT, pm, SErr.SE_PT,SErr.PC, pm, SErr.SE_PC,
			SErr.ARL, pm, SErr.SE_ARL,SErr.ARM, pm, SErr.SE_ARM, SErr.PTS, pm, SErr.SE_PTS, 
			SErr.PTP, pm, SErr.SE_PTP, SErr.PTCN, pm, SErr.SE_PTCN, 
			SErr.AEI, pm, SErr.SE_AEI, SErr.APC, pm, SErr.SE_APC);

		fclose(ff);
	}
	exit(0);
}


//==================================================================================
// image-processing function
//==================================================================================

bool myTrackbarRmin(int, void*) {

        double tmp;
	int itr=0;
	int flag1 = 1;  
	int lval=0, pval=0;
	int lval_b = 0, pval_b = 0;
	int thr=0;
	int step = 5;
	int step1 = 3;

	int cnt_no = 0;
	double minm = 6500000;
	double match = 0;
	int nn = 0;
	
	// Determination the threshold value of R-channel for corolla contour detection
	for( int y = 10; y < rgb.rows-10; y++ ) { 
		for( int x = 10; x < rgb.cols-10; x+=step ) { 
		pval = lval;
		pval_b = lval_b;
		lval = saturate_cast<uchar>(rgb.at<Vec3b>(y,x)[2]); // red
		lval_b = saturate_cast<uchar>(rgb.at<Vec3b>(y,x)[1]); // blue
		if(x!=10 && abs(lval-pval) > 20 && abs(lval_b-pval_b) < 85) {
			thr += (saturate_cast<uchar>(rgb.at<Vec3b>(y, x-step-step1)[2]) + saturate_cast<uchar>(rgb.at<Vec3b>(y, x+step1)[2])) / 2 ;
			itr++;	
			break;
			}
		}

		for( int x = rgb.cols-10; x > 10; x-=step ) { 
		pval = lval;
		pval_b = lval_b;
		lval = saturate_cast<uchar>(rgb.at<Vec3b>(y,x)[2]);
		lval_b = saturate_cast<uchar>(rgb.at<Vec3b>(y,x)[1]); // blue
		if(x!=rgb.cols-10 && abs(lval-pval)>20 && abs(lval_b-pval_b) < 85) {
			thr += (saturate_cast<uchar>(rgb.at<Vec3b>(y, x-step1)[2]) + saturate_cast<uchar>(rgb.at<Vec3b>(y, x+step+step1)[2])) / 2 ;
			itr++;	
			break;
			}
		} 
	} 
	Rmin = (int)(((double)thr / itr)  * 0.9) ; // the threshold value of R-channel for corolla contour detection


	//threshold transformation
	threshold(r_plane, r_range, Rmin, Rmax, THRESH_BINARY);

	// finding contours
		findContours(r_range, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point());
		contour_no = 0;

	// Comparison of all revealed contours with template contours of corolla

	//#########################################################################
	bool ifflag = false;
		cnt_no = -1;
		minm = 650000.0;
		match = 0;
		for(contour_no = 0, match = 0; contour_no < contours.size(); contour_no++) {
			 match = matchShapes(contours[contour_no], RTemplate[RTemplateContour_no], CV_CONTOURS_MATCH_I3, 0);
			 match += matchShapes(contours[contour_no], RTemplate1[RTemplateContour1_no], CV_CONTOURS_MATCH_I3, 0);
			 if((match < minm) && (contours[contour_no].size() > 600) ) {
				 minm = match;
				 cnt_no = contour_no;
				 ifflag = true;
				}
			}
		if(!ifflag) return ifflag;
		contour_no = cnt_no;

//#################################################################################

		int i = 0, j = 0, k = 0;
		//Approximation of contour with pentagon
		int ap_no = 5;
		int range = approxRange(contours[contour_no], ap_no);
		vector<vector<Point> > approx(contours.size());
		approxPolyDP(contours[contour_no], approx[contour_no], range, true);
		oldcon = approx;

		
		// Convex Hull operations
		vector<vector<Point> > hull(contours.size());
		convexHull(contours[contour_no], hull[contour_no], true, true);


		vector <int> hIdx; //(hIdx.size());
		vector <Vec4i> hdef(hull[contour_no].size() + 10);

		// preparing an array of indexes from the approximation arra of petals vertices
		hIdx = curvePoints2Indices(contours[contour_no], approx[contour_no]);
		convexityDefects(contours[contour_no], hIdx, hdef);
	
		vector<Point> hcon(hdef.size()); 
		vector<Point> hcon1(hdef.size());
		for (int i = 0; i < hdef.size(); i++) {
			hcon.at(i) = contours[contour_no][hdef[i][2]];
			hcon1.at(i) = contours[contour_no][hdef[i][2]];
		}
		hcon1.resize(hdef.size() - 1);

	
	// Finding of external and internal corolla vertices by the new "Walking" method

		vector < vector <Point >> ds;
		ds = getCriticalPoints(contours, contour_no);

		if (ds[0][0] != Point(0, 0)) {

			// overdetermination of vertices arrays
			approx[contour_no].resize(vecon.size());
			approx[contour_no] = vecon;
			hcon.resize(vicon.size());
			hcon = vicon;
			hcon1.resize(vicon.size());
			hcon1 = vicon;
			tcc.resize(vcon.size());
			tcc = vcon;
			
		}
//##########################################################################################

		
		// drawing contour, circle 
		drawContours(rgb, contours, contour_no, y_color, 2, 8, hierarchy, 0, Point() );
		minEnclosingCircle(contours[contour_no], center, radius);
		circle(rgb, center, radius, p_color, 2,8,0);
		// drawing center
		circle(rgb, center, 3, p_color, 2,8,0);

		// Get the moments
		vector<Moments> mu(contours.size()+1 );
		for( int i = 0; i < contours.size(); i++ )
			{ mu[i] = moments( contours[i], false ); }
		
		// Get the mass centers:
		mc.resize( contours.size() +1);
		mc.assign(contours.size(), Point2f(0,0));
		vector<Point2f> ma( contours.size() +1); // asymmetry
		for( int i = 0; i < contours.size(); i++ ) {

		// Get central moments
		mc[i] = Point2f( mu[i].m10/mu[i].m00 , mu[i].m01/mu[i].m00 ); 
		ma[i] = Point2f(mu[i].nu30/powf(sqrtf(mu[i].nu20), 3), mu[i].nu03/powf(sqrtf(mu[i].nu02), 3) );
		}
		// Draw mass center
		circle( rgb, mc[contour_no], 2, Scalar(256,0,0), 2, 8, 0 );
	
		
		

		// draw radials; radial linear asymmetry calculation
		double radasymmetry = 0;
		double radasymmetry1 = 0;
		int temp = 0;
		vector<Point> depr ( approx.size() );
		vector<Point> depr1 ( approx.size() );
					
	//if only 5 external vertices are in consideration
		int temporal = 0;
	if(ap_no == 5) { // calculation of sum of meansquare deviatin of external vertices radial from radius
		for(i = 0; i < approx[contour_no].size(); i++) {
			 radasymmetry += pow(radius - dist(approx[contour_no][i], center), 2);
			 }
		temporal = i;


		for (i = 0; i<vecon.size(); i++)
			circle(rgb, vecon[i], 5, r_color, 3, 8, 0);
		for (i = 0; i < vecon.size() - 2; i++) {
			for (j = i + 2; j < vecon.size(); j++) {
				if (i == 0 && j == vecon.size() - 1)
					continue;
				line(rgb, vecon[i], vecon[j], r_color, 2, 8, 0);
				circle(rgb, vecon[i], 3, r_color, 3, 8, 0);
			}
		}


	} // end of 5 vertices model
	
	 //all 10 vertices model
	if(ap_no == 10) {
		for(i = 0, j = 0; i < approx[contour_no].size(); i+=2, j++) {
			 radasymmetry += radius - dist(approx[contour_no][i], center);
			 depr[j] = approx[contour_no][i];
			}
		temp = j;

		for(i = 1, j = 0; i < approx[contour_no].size(); i+=2, j++) {
			 radasymmetry1 += radius - dist(approx[contour_no][i], center);
			 depr1[j] = approx[contour_no][i];
			}
		depr.resize(temp);
		depr1.resize(j);
		
		minEnclosingCircle(depr1, cen, rad);
		if(rad <= radius) {
			circle(rgb, cen, rad, b_color, 2,8,0);
			radasymmetry /= ((temp - 1) * radius);
			radasymmetry1 -= (radius - rad)*(j - 1);
			radasymmetry1 /= ((j - 1) * rad);
			}
		else {
			minEnclosingCircle(depr, cen, rad);
			circle(rgb, cen, rad, b_color, 2,8,0);
			radasymmetry /= ((temp - 1) * radius);
			radasymmetry1 -= (rad - radius)*(j - 1);
			radasymmetry1 /= ((j - 1) * rad);
			double tt = radasymmetry;
			radasymmetry = radasymmetry1;
			radasymmetry1 = tt;
		}

		for( i = 0; i < depr.size()-2; i++) {
			for( j = i+2; j < depr.size(); j++) {
				if(i == 0 && j == depr.size()-1)
					continue;
					line(rgb, depr[i], depr[j], y_color, 2, 8, 0);
				}
		}
		for( i = 0; i < depr1.size()-2; i++) {
			for( j = i+2; j < depr1.size(); j++) {
				if(i == 0 && j == depr1.size()-1)
					continue;
					line(rgb, depr1[i], depr1[j], b_color, 2, 8, 0);
				}
		}
	} //end of 10 vertices model

		//drawing vertices and lines		
		minEnclosingCircle(hcon, cen, rad);
		circle(rgb, cen, rad, bb_color, 2,8,0);
		circle(rgb, cen, 3, bb_color, 2,8,0);

		for (i = 0; i < vcon.size(); i++) {
			if (i != vcon.size() - 1)
				line(rgb, vcon.at(i), vcon.at(i+1), y_color, 2,8,0);
			else
				line(rgb, vcon.at(i), vcon.at(0), y_color, 2, 8, 0);
		}
		for (i = 0; i < vicon.size(); i++) {
			if (i != vicon.size() - 1)
				line(rgb, vicon.at(i), vicon.at(i + 1), g_color, 2, 8, 0);
			else
				line(rgb, vicon.at(i), vicon.at(0), g_color, 2, 8, 0);
			
			circle(rgb, vicon.at(i), 5, g_color, 3, 8, 0);
		}

		for (i = 0; i < vecon.size(); i++) {
			if (i != vecon.size() - 1)
				line(rgb, vecon.at(i), vecon.at(i + 1), r_color, 2, 8, 0);
			else
				line(rgb, vecon.at(i), vecon.at(0), r_color, 2, 8, 0);
		}

		//sum of meansquare deviatins of inner vertices from minor radius
		for(i = 0; i < hcon.size(); i++) 
			radasymmetry += pow(rad - dist(hcon[i], cen), 2);
		ARL = sqrt(radasymmetry) / ((temporal + i) * rad); //radial linear asymmetry


		// contour slices extraction and radial mass asymmetry calculation
		double rad_mass_asym = 0, mass_sum = 0;
		double pairs = 0;
		vector <double> slice_mass (contours[contour_no].size() );
		vector <vector<Point> > cc;

		slice_mass.assign(slice_mass.size(), 0);

		vector <vector <Point>> ccc (contours.size());
		bool iflag = false;

		for(i = 0; i < tcc.size(); i++) {

			if (tcc.size()- i - 1 > 0)
				cc = contourSliceNew(contours, contour_no, sIdx[i], sIdx[i + 1], mc[contour_no]);
			else
				cc = contourSliceNew(contours, contour_no, sIdx[i], sIdx[0], mc[contour_no]);
			
			slice_mass[i] = contourArea(cc[contour_no], false);
			mass_sum += slice_mass[i];
			drawContours(rgb, cc, contour_no, bk_color, 2, 8, hierarchy, 0, Point() );
		} 

		double pet_sum = 0; // petals asymmetry calculation
		if(iflag) {
			for(i = 0; i < tcc.size() - 1; i++)
				pet_sum += pow(slice_mass[i] - slice_mass[i + 1], 2);
		}
		else {
			for(i = 1; i < tcc.size() - 1; i++)
				pet_sum += pow(slice_mass[i] - slice_mass[i + 1], 2);
			pet_sum += pow(slice_mass[0] - slice_mass[tcc.size()-1],2);
		}
		PA = sqrt(pet_sum)/mass_sum; // petals asymmetry


		for(i = 0; i < tcc.size(); i++) // radial mass asymmetry calculation
			pairs += slice_mass[i];
		pairs /= i;
		for(i = 0; i < tcc.size(); i++)
			rad_mass_asym += pow(slice_mass[i] - pairs, 2);
		ARM = sqrt(rad_mass_asym)/(pairs * i); // radial mass asymmetry

		
		

	// conversion of colors from RGB to HSV
	Mat hsv_frame;
	cvtColor(frame, hsv_frame, CV_BGR2HSV);
	// Hue extraction
	vector <Mat> hsv_sum; 	
	split(hsv_frame, hsv_sum);
	hsv_h = hsv_sum[0]; //Hue

// threshold transformation and determination of the inner corolla contour
 Mat hsv_ht;  
 threshold(hsv_h, hsv_ht, 50, 255, THRESH_BINARY);
 findContours(hsv_ht, c_contours, c_hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0,0));
 
 // comparison of detected contours with template contour
		cnt_no = -1;
		minm = 650000;
		match = 0;
		for(c_contour_no = 0; c_contour_no < c_contours.size(); c_contour_no++) {
			 match = matchShapes(c_contours[c_contour_no], RCTemplate[RCTemplateContour_no], CV_CONTOURS_MATCH_I3, 0);
			 if((match < minm) && (c_contours[c_contour_no].size() > 300) && pointPolygonTest(c_contours[c_contour_no], Point2f(10,10), false) < 0 ) {
				 minm = match;
				 cnt_no = c_contour_no;
				}
			}
		c_contour_no = cnt_no;

// drawing inner contour, circle and center 
 drawContours(rgb, c_contours, c_contour_no, y_color, 2, 8, c_hierarchy, 0, Point(0,0));
 if(c_contour_no < c_contours.size()) { 
	minEnclosingCircle(c_contours[c_contour_no], c_center, c_radius);
	circle(rgb, c_center, c_radius, b_color, 2, 8, 0);
	circle(rgb, c_center, 2, b_color, 2, 8, 0);
}       //visualization of both Red and Hue threshold transformations
	imshow("R + Hue Threshold", r_range.mul(hsv_h/1.2));
return true;	
}

//////////////////////////////////////////////////////////////////////////////////////////

//Preliminary image processing and the main image processing & data calculating cycle
//////////////////////////////////////////////////////////////////////////////////////////
int Rcontours(char *s)
{
	rData RDat;
	int j=0,k=0;

	RDat.number=0;
	RDat.compactness=0;
	RDat.perimeter=0;
	RDat.radius=0;
	RDat.square=0;
	RDat.asymmetry = 0;
	RDat.PA = 0; 
	RDat.PID = 0;
	RDat.PT = 0; 
	RDat.PC = 0; 
	RDat.ARL = 0; 
	RDat.ARM = 0; 
	RDat.PTS = 0; 
	RDat.PTP = 0; 
	RDat.PTCN = 0;
	RDat.AEI = 0; 
	RDat.APC = 0; 


	double tmp;
	int itr=0;
	int flag1 = 1;  
	int lval=0, pval=0;
	int lval_b = 0, pval_b = 0;
	int thr=0;
	int step = 5;
	int step1 = 3;

	int cnt_no = 0;
	double minm = 6500000;
	double match = 0;
	contour_no = 0;
	
	GaussianBlur( image, rgb, Size(5, 5), 0, 0 );

	
	image = rgb.clone();
	split( rgb, res );
	r_plane = res[2]; //red channel
		
	namedWindow("R + Hue Threshold", WINDOW_AUTOSIZE);
	// main image processing
	myTrackbarRmin(0,0);
	imshow("contours", rgb);

	

	while(flag1) {
		//rgb = image.clone();
		char c=waitKey(33);
			if(c==13) { 
				flag1 = 0; 
				// go to the main cycle
				sprintf(filename, "%s%d.jpg", path, counter);
				sprintf(Dat[counter].fname, "%s%d.jpg",s, counter);
				cntr = Point2f(width/4-height/4+center.y, height/4+width/4-center.x); 
				break; 
				}
			if(c==27) { 
				// return to the live camera window
				destroyWindow("contours");
				destroyWindow("Measuring");
				destroyWindow("R + Hue Threshold");
				counter--; 
				ThFlag = false;
				return -1;
				}
			if(c==32 && flag1 == 1 && contour_no < contours.size()) contour_no++;
			if(c == 'i') { //writing window "contours" to file
				char nnn[32];
				srand(time(NULL));
				int random_n = rand() % 32767;
				int random_n1 = rand() % 32767;
				sprintf(nnn, "%05d%05d.jpg", random_n, random_n1);
				imwrite(nnn, rgb);
			}
			if(c == 'y') { // determination of the mean corolla color
				vector <float> res (6);
				Mat pColor = Mat::zeros (image.size(), image.type());
				pColor.setTo(Scalar(255,255,255));
				res = findColors(image, contours[contour_no], c_contours[c_contour_no]);
				drawContours(pColor, contours, contour_no, Scalar(res[0], res[1], res[2]), CV_FILLED);
				drawContours(pColor, c_contours, c_contour_no, Scalar(255, 255, 255), CV_FILLED);
				imshow("Mean Color",pColor);
			}

			if(c == 'f') {
				//findFeatures(contours[contour_no], RTemplate[RTemplateContour_no]);
				getCriticalPoints(contours, contour_no); // 
			} 

			if(c == 'w') { // writing contours to file as templates
				int Rsize = contours[contour_no].size();
				int RContoursSize = contours.size();
				FileStorage fs("RContour3.xml", FileStorage::WRITE);
				fs << "RContoursSize" << RContoursSize;
				fs << "RTemplateContour_no" << contour_no;
				fs << "RTemplate_size" << Rsize;
				fs << "RTemplate";
				fs << "[";                              // text - string sequence
				for(int i = 0; i< contours[contour_no].size(); i++) {
					fs << contours[contour_no][i].x;
					fs << contours[contour_no][i].y;
				}
				fs << "]";  
				fs.release();
			}
			if(c == 'c') { // writing inner contour to file as template
				printf("\nc_contour_no = %d c_contours[c_contour_no].size() = %d",c_contour_no , c_contours[c_contour_no].size());
				int RCsize = c_contours[c_contour_no].size();
				int RCContoursSize = c_contours.size();
				FileStorage cfs("RCContour.xml", FileStorage::WRITE);
				cfs << "RCContoursSize" << RCContoursSize;
				cfs << "RCTemplateContour_no" << c_contour_no;
				cfs << "RCTemplate_size" << RCsize;
				cfs << "RCTemplate";
				cfs << "[";                              // text - string sequence
				for(int i = 0; i< c_contours[c_contour_no].size(); i++) {
					cfs << c_contours[c_contour_no][i].x;
					cfs << c_contours[c_contour_no][i].y;
				}
				cfs << "]";  
				cfs.release();
			}
			if(c=='r') {// reading template contour from file
				FileStorage fs("RContour1.xml", FileStorage::READ);
				int RContours_size = (int) fs["RContoursSize"];
				RTemplateContour_no = (int) fs["RTemplateContour_no"];
				int RTemplate_size = (int) fs["RTemplate_size"];
				vector <vector  <Point> > RTemplate( RContours_size, vector <Point> (RTemplate_size));
				FileNode n = fs["RTemplate"];
				FileNodeIterator it = n.begin(), it_end = n.end(); // Go through the node
				for (int i=0; it != it_end; ++it,i++) {
					RTemplate[contour_no][i].x = (int ) *(it++);
					RTemplate[contour_no][i].y = (int) *it;
				}
			fs.release();
			drawContours(rgb, RTemplate, contour_no, color, 2, 8, hierarchy, 0, Point(5,5) );
			imshow("contours", rgb);
			}
	}

			
	// THE MAIN IMAGE PROCESSING AND CALCULATING CYCLE
	clock_t tt, ttt;
	tt = clock();

	RDat.number=0;
	RDat.compactness=0;
	RDat.perimeter=0;
	RDat.radius=0;
	RDat.square=0;
	RDat.asymmetry = 0;
	RDat.PA = 0;
	RDat.PID = 0;
	RDat.PT = 0; 
	RDat.PC = 0; 
	RDat.ARL = 0; 
	RDat.ARM = 0; 
	RDat.PTS = 0; 
	RDat.PTP = 0;
	RDat.PTCN = 0;
	RDat.AEI = 0;
	RDat.APC = 0;

	for(j=0,k=0;j < rep;j++,k++){ // main cycle
		ttt = clock();
		
		
		capture >> frame; // get frame from camera
		

		Mat Fframe (frame, Rect(cntr.x, cntr.y, mwidth,mheight));
		frame = Fframe;
		image = frame.clone();

	//  blur filter
	GaussianBlur( image, rgb, Size(5, 5), 0, 0 );
	
	image = rgb.clone();
	if(j == 0) {imwrite(filename, image); } // writing image to file
	// split image in R G B channels
	split( rgb, res );
	r_plane = res[2]; //red channel

	bool ifflag = false;
	ifflag = myTrackbarRmin(0,0); // main image processing
	if(!ifflag) {j--; continue;}

		
	//put text in window
	char RR[32];
	sprintf(RR,"Rmin=%d", Rmin);
	putText(rgb, RR, Point(rgb.cols-170, rgb.rows-22), FONT_HERSHEY_COMPLEX, 0.45, Scalar(0,0,0), 1, 8, false);
	sprintf(RR,"%d", j + 1);
	putText(rgb, RR, Point(rgb.cols-45, rgb.rows-4), FONT_HERSHEY_COMPLEX, 0.45, Scalar(0,0,0), 1, 8, false);
	putText(rgb, "R", Point(rgb.cols-60, rgb.rows-22), FONT_HERSHEY_COMPLEX_SMALL, 3, Scalar(255,0,0), 2, 8, false);
	imshow("Measuring", rgb);

	// Calculating parameters
	RDat.square += contourArea(contours[contour_no]);
	RDat.perimeter += arcLength(contours[contour_no],true);
	RDat.radius += radius;
	RDat.asymmetry += getAsymmetry(center, mc[contour_no], radius);
	RDat.PTS += contourArea(c_contours[c_contour_no]);
	RDat.PTP += arcLength(c_contours[c_contour_no], true);
	RDat.PTCN += (RDat.PTS * pi * 4) / (RDat.PTP * RDat.PTP); 
	RDat.PT += c_radius;
	RDat.PID += (radius - rad);
	RDat.PC += (radius - c_radius);
	RDat.AEI += dist(center, cen) / (radius - rad);
	RDat.APC += dist(center, c_center) / (radius - c_radius);
	RDat.PA += PA; 
	RDat.ARL += ARL;
	RDat.ARM += ARM;

	cDat[j].square = contourArea(contours[contour_no]);
	cDat[j].perimeter = arcLength(contours[contour_no],true);
	cDat[j].radius = radius;
	cDat[j].compactness = cDat[j].square/(cDat[j].perimeter * cDat[j].perimeter);
	cDat[j].asymmetry = getAsymmetry(center, mc[contour_no], radius);
        cDat[j].Ncompactness = cDat[j].compactness*pi * 4;
	cDat[j].asymmetry = getAsymmetry(center, mc[contour_no], radius);
	cDat[j].PTS = metric*metric*contourArea(c_contours[c_contour_no]); 
	cDat[j].PTP = metric*arcLength(c_contours[c_contour_no], true); 
	cDat[j].PTCN = (cDat[j].PTS * pi * 4) / (cDat[j].PTP * cDat[j].PTP); 
	cDat[j].PT = metric*c_radius;
	cDat[j].PID = metric*(radius - rad);
	cDat[j].PC = metric*(radius - c_radius);
	cDat[j].AEI = dist(center, cen) / (radius - rad);
	cDat[j].APC = dist(center, c_center) / (radius - c_radius);
	cDat[j].PA = PA; 
	cDat[j].ARL = ARL;
	cDat[j].ARM = ARM;


	waitKey(1);

	putText(rgb, "R", Point(rgb.cols-60, rgb.rows-22), FONT_HERSHEY_COMPLEX_SMALL, 3, Scalar(0,0,256), 2, 8, false);
	ttt = clock() - ttt;
	sprintf(RR,"%.3f sec",(float)ttt/CLOCKS_PER_SEC);
	if(j != rep - 1)
		putText(rgb, RR, Point(rgb.cols-170, rgb.rows-4), FONT_HERSHEY_COMPLEX, 0.45, Scalar(0,0,0), 1, 8, false);
	imshow("Measuring", rgb);
	waitKey(1);
	} //end of the main cycle


	tt = clock() - tt;
	char RR[32];
	sprintf(RR,"%.3f sec",(float)tt/CLOCKS_PER_SEC);
	putText(rgb, RR, Point(rgb.cols-170, rgb.rows-4), FONT_HERSHEY_COMPLEX, 0.45, Scalar(0,0,0), 1, 8, false);
	WriteFlag = true;
	putText(rgb, "R", Point(rgb.cols-60, rgb.rows-22), FONT_HERSHEY_COMPLEX_SMALL, 3, Scalar(0,256,0), 2, 8, false);
	char nnnn[10];
	sprintf(nnnn,"%d",counter+1);
	putText(rgb, nnnn, Point(rgb.cols-90, rgb.rows-80), FONT_HERSHEY_COMPLEX_SMALL, 2, b_color, 2, 8, false);
	imshow("Measuring", rgb); 

	//final calculations
	Dat[counter].square =metric*metric*RDat.square/ j;
	Dat[counter].perimeter = metric*RDat.perimeter/ j;
	Dat[counter].radius = metric*RDat.radius/ j;
	Dat[counter].compactness = Dat[counter].square/(Dat[counter].perimeter * Dat[counter].perimeter);
	Dat[counter].asymmetry = RDat.asymmetry/ j;
	Dat[counter].PTS = RDat.PTS * metric * metric / j; //square flower tube 
	Dat[counter].PTP = RDat.PTP * metric / j; // perimeter flower tube 
	Dat[counter].PTCN = RDat.PTCN / j; // compactness flower tube 
	Dat[counter].PT = RDat.PT * metric / j;
	Dat[counter].PID = RDat.PID * metric / j;
	Dat[counter].PC = RDat.PC * metric / j;
	Dat[counter].AEI = RDat.AEI / j;
	Dat[counter].APC = RDat.APC / j;
	Dat[counter].ARL = RDat.ARL / j;
	Dat[counter].ARM = RDat.ARM / j;
	Dat[counter].PA =  RDat.PA / j;


	printf("\nj=%d k=%d rep=%d Contour Square = %lf\tPerimeter = %lf\tCompactness = %lf\tRadius = %lf", j, k, rep, Dat[counter].square, Dat[counter].perimeter, Dat[counter].compactness, Dat[counter].radius);
	
	while(char c = waitKey(33)) {
	if (c == 27) { // exit for the next flower cycle
		Write_cData();
		if(WriteFlag)
			WriteResFile(s);
		destroyWindow("R + Hue Threshold");
		destroyWindow("contours");
		destroyWindow("Measuring");
		break;
		}
	}
	
	return 0;
}


Mat ImageAdjust(Mat image, double alpha, int beta) 
{	
//double alpha = 1.25; //< Simple contrast control 
//int beta = 25; //< Simple brightness control 

Mat new_image = Mat::zeros( image.size(), image.type() );
image.convertTo(new_image, -1, alpha, beta);
 
//Sharpen image 
//Mat kern = (Mat_<char>(3,3) << 0, -1, 0, 
//-1, 5, -1,
//0, -1, 0);
//filter2D(new_image, new_image, new_image.depth(), kern );
//filter2D(new_image, new_image, new_image.depth(), kern );
return new_image;
}

double getAsymmetry(Point center, Point masscenter, double radius)
{
	return (sqrtf(((center.x - masscenter.x) * (center.x - masscenter.x) + (center.y - masscenter.y) * (center.y - masscenter.y))) / radius);
}

