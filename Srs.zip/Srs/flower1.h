#include "opencv\cv.h"
#include "opencv\highgui.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <math.h>
#include <direct.h>
#include <valarray>
#include <vector>
#include <iterator>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include "opencv2\core\core.hpp"
#include "opencv2\opencv.hpp"
#include "opencv2\opencv_modules.hpp"
#include "opencv2\imgproc\imgproc.hpp"
#include "opencv2\highgui\highgui.hpp"
#include "opencv2\highgui\highgui_c.h"
#include "opencv2\features2d\features2d.hpp"
#include <Windows.h>


using namespace cv;
using namespace std;

// ���� ������
struct rData {
	int number;
	char fname[512];
	double square;
	double perimeter;
	double compactness;
	double Ncompactness;
	double radius;
	double asymmetry;
	double PA; // mass petals asymmetry
	double PID; // debth of petals incision
	double PT; // flower tube radius
	double PC; // petals ring width
	double ARL; // linear radial asymmery of the flower
	double ARM; // mass radial asymmery of the flower
	double PTS; // square of the flower tube ochrea
	double PTP; // perimetre of the flower tube ochrea
	double PTCN; // compactness of the flower tube ochrea
	double AEI;  // asymmetry of external and internal corolla vertices 
	double APC; // petals ring asymmetry
	};

struct eData {
	double square;
	double perimeter;
	double compactness;
	double Ncompactness;
	double radius;
	double asymmetry;
	double PA; // mass petals asymmetry
	double PID; // debth of petals incision
	double PT; // flower tube radius
	double PC; // petals ring width
	double ARL; // linear radial asymmery of the flower
	double ARM; // mass radial asymmery of the flower
	double PTS; // square of the flower tube ochrea
	double PTP; // perimetre of the flower tube ochrea
	double PTCN; // compactness of the flower tube ochrea
	double AEI;  // asymmetry of external and internal corolla vertices 
	double APC; // petals ring asymmetry

	// standart errors of values
	double SEsquare;
	double SEperimeter;
	double SEcompactness;
	double SENcompactness;
	double SEradius;
	double SEasymmetry;
	double SE_PA; 
	double SE_PID;
	double SE_PT; 
	double SE_PC; 
	double SE_ARL;
	double SE_ARM;
	double SE_PTS;
	double SE_PTP;
	double SE_PTCN;
	double SE_AEI; 
	double SE_APC; 
};


// Functions prototypes
bool myTrackbarRmin(int, void*);
Mat ImageAdjust(Mat image, double alpha, int beta); 
int Rcontours(char *s);
int ReadResFile(char *name);
int WriteResFile(char *name);
void RotateImage(Mat Source, Mat Dest);
void Write_cData(void);
void StError(void);
Mat rotateImage(const Mat source, double angle, Point2f src_center);
void findObjects(void);
void RedContours(void);
void GreenContours(void);
void adjustFrame(void);
double getAsymmetry(Point center, Point masscenter, double radius);
double dist(Point p1, Point p2);
int approxRange(vector<Point> contour, int apex_no);
vector <vector <Point>> contourSliceNew(vector <vector<Point>> cnt, int cnt_no, int p1, int p2, Point cent);
vector <int> curvePoints2Indices(vector <Point> contour, vector <Point> pset);
vector <float> findColors(Mat img, vector <Point> c1, vector <Point> c2);
void findFeatures(vector <Point> cntr1, vector <Point> cntr2);
vector <vector <Point>> getCriticalPoints(vector <vector <Point>> con, int con_no);
vector <double> getAngles(vector <Point> v, Point c);
int cycVec(int pos, int size);
char * GetFile(void);


// external variables
#if defined _MAIN__
CvCapture* ccapture;
VideoCapture capture;
rData Dat[1024];
Mat image;
Mat frame;
Mat rgb, rgb1;
Mat r_plane;
Mat g_plane;
Mat bin, g_bin;
Mat r_range; 
Mat g_range;
Mat hsv_h;
vector <Mat> res;
Mat Rframe, Rframe1;
Mat RotatedFrame;
Mat map_x, map_y;
int Rmin = 125; //190; //165,145;
int Rmax = 255; //250;
int Gmin = 120; //140; //120,110;
int Gmax = 255; //250;
int RGBmax = 255;

char filename[512]="";
char path[512]="";
bool WriteFlag = false;
bool ThFlag = false;
int st_thr;
float st_lim;

RNG rng(12345);
int counter=0;
double angle = 0;
vector<vector <Point> > contours, g_contours, c_contours, oldcon;
vector <Point> vecon(15), vicon(15), vcon(15);
vector<Vec4i> hierarchy, g_hierarchy, c_hierarchy;
vector<Point2f> mc_t, g_mc_t;
vector<Point2f> mc;
vector <Point> tcc (20);
vector <int> sumIdx;
vector <int> sIdx;



Point2f center, g_center, s_center, cntr, c_center;
Point2f cen;
float rad = 0;
int contour_no = 0, c_contour_no=0;
int g_contour_no = 0;
float radius, g_radius, c_radius;
vector<RotatedRect> r_minRect(1024), g_minRect(1024);

	Scalar color = Scalar(0,0,255);//red
	Scalar w_color = Scalar(255,255,255);//white
	Scalar bk_color = Scalar(0,0,0);//black
	Scalar b_color = Scalar(255,0,0);//blue
	Scalar r_color = Scalar(0,0,255); //�������
	Scalar m_color = Scalar(255,0,255);//magenta
	Scalar g_color = Scalar(0,255,0);//green
	Scalar color1 = Scalar(0,0,255);//red
	Scalar g_color1 = Scalar(0,255,0);//green
	Scalar y_color = Scalar(0,255,255);//yellow
	Scalar bb_color = Scalar(255,255,128);//light blue
	Scalar p_color = Scalar(192,192,255);//pink

	Vec3b y_col = Vec3b(128,255,255);
	Vec3b w_col = Vec3b(255,255,255);
	Vec3b bk_col = Vec3b(0,0,0);
	Vec3b b_col = Vec3b(255,0,0);
	Vec3b r_col = Vec3b(0,0,255);
	Vec3b m_col = Vec3b(255,0,255);
	Vec3b g_col = Vec3b(0,255,0);
	

vector <vector <Point> > RTemplate, RTemplate1, RCTemplate;
int RTemplateContour_no;
int RTemplateContour1_no;
int RCTemplateContour_no;

int width=1280, height=1024, mwidth, mheight;
int rep = 50;
rData cDat[100];
eData SErr;
double pi = 3.14159265359;
double metric = 0.059277; //pixel in millimetres
	//0.05584; 
int no_asymmetry_data = 0;
int no_PA; // absence of previous data in complex papameters
double PA = 0, ARL = 0, ARM = 0;

#endif

#if defined _FILE__
extern rData Dat[1024];
extern int counter;
extern int rep;
extern rData cDat[100];
extern eData SErr;
extern double metric;
extern double pi;
extern int no_asymmetry_data;
extern int no_PA;
#endif

#if defined _FUNC__
extern vector<vector <Point> > oldcon;
extern vector <Point> vecon,vicon,vcon;
extern Point2f center;
extern 	Scalar w_color;
extern Mat rgb, image;
extern vector <vector <Point> > RTemplate, RTemplate1, RCTemplate;
extern int RTemplateContour_no;
extern int RTemplateContour1_no;
extern int RCTemplateContour_no;
extern vector<vector <Point> > contours, g_contours, c_contours;
extern int contour_no, c_contour_no;
extern vector <Point> tcc;
extern vector <int> sumIdx;
extern vector <int> sIdx;
extern bool ThFlag;
extern int st_thr;
extern float st_lim;

	extern Scalar color;
	extern Scalar w_color;
	extern Scalar bk_color;
	extern Scalar b_color;
	extern Scalar r_color;
	extern Scalar m_color;
	extern Scalar g_color;
	extern Scalar color1;
	extern Scalar g_color1;
	extern Scalar y_color;
	extern Scalar bb_color;
	extern Scalar p_color;

	extern Vec3b y_col;
	extern Vec3b w_col;
	extern Vec3b bk_col;
	extern Vec3b b_col;
	extern Vec3b r_col;
	extern Vec3b m_col;
	extern Vec3b g_col;

#endif